Copy ../test.json here, and run split_by_num.py to split the test data by triple nums.
