1) Move test_seo.json, test_normal.json, test_epo.json to this folder
2) Run generate_triples.py to get triple files.
