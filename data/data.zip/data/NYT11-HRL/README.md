1) Download the NYT11-HRL dataset from [here](https://github.com/truthless11/HRL-RE/tree/master/data/NYT11).
2) Run build_data.py
