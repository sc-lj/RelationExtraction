Move the split files from raw_WebNLG/ here.

Then run generate_triples.py to get triple files.
