First, download and process the raw WebNLG data in dir raw_WebNLG/

Then run build_data.py to get triple files.

