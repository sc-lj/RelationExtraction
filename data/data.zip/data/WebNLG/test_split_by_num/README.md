Copy ../test.json to here.

Run split_by_num.py to split the test dataset and store the split files in the form of triples.
